let isRunning = false;
let time = 0;
let interval;
let lapTimes = [];

function formatTime(ms) {
    const minutes = Math.floor(ms / 60000);
    const seconds = Math.floor((ms % 60000) / 1000);
    const milliseconds = ms % 1000;
    return `${pad(minutes)}:${pad(seconds)}.${pad(milliseconds, 3)}`;
}

function pad(num, size = 2) {
    return ('000' + num).slice(-size);
}

function startStop() {
    if (isRunning) {
        clearInterval(interval);
        document.getElementById("start-stop").textContent = "Start";
    } else {
        interval = setInterval(() => {
            time++;
            document.getElementById("display").textContent = formatTime(time);
        }, 10);
        document.getElementById("start-stop").textContent = "Pause";
    }
    isRunning = !isRunning;
}

function reset() {
    clearInterval(interval);
    isRunning = false;
    time = 0;
    document.getElementById("display").textContent = "00:00.00";
    lapTimes = [];
    updateLapList();
    document.getElementById("start-stop").textContent = "Start";
}

function recordLap() {
    if (isRunning) {
        lapTimes.push(time);
        updateLapList();
    }
}

function updateLapList() {
    const lapList = document.getElementById("lap-list");
    lapList.innerHTML = ""; // Clear existing laps

    lapTimes.forEach((lapTime, index) => {
        const lapItem = document.createElement("li");
        lapItem.textContent = `Lap ${index + 1}: ${formatTime(lapTime)}`;
        lapList.appendChild(lapItem);
    });
}
